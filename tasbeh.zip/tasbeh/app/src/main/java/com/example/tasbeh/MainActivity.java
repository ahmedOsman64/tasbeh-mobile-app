package com.example.tasbeh;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView countText, zikrText;
    private Button incrementButton, resetButton, changeZikrButton;

    private int count = 0;
    private int zikrIndex = 0;

    private final String[] zikrList = {
            "سُبْحَانَ اللهِ",               // SubhanAllah
            "ٱلْـحَمْدُ لِلّٰهِ",             // Alhamdulillah
            "اللّٰهُ أَكْبَرُ",               // Allahu Akbar
            "أَسْتَغْفِرُ اللّٰهَ",           // Astaghfirullah
            "لَا إِلٰهَ إِلَّا اللّٰهُ",      // La ilaha illallah
            "سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ", // SubhanAllahi wa bihamdihi
            "سُبْحَانَ اللّٰهِ الْعَظِيمِ",   // SubhanAllahi al-‘Azim
            "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللّٰهِ", // La hawla wa la quwwata illa billah
            "رَبِّ اغْفِرْ لِي",              // Rabbi ighfir li
            "اللّٰهُمَّ صَلِّ عَلَى مُحَمَّدٍ", // Allahumma salli ‘ala Muhammad
            "اللّٰهُمَّ ارْزُقْنِي الْجَنَّةَ", // Allahumma arzuqni al-jannah
            "اللّٰهُمَّ أَجِرْنِي مِنَ النَّارِ" // Allahumma ajirni mina an-naar
    };


    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Handle system insets (status/navigation bars)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize SharedPreferences
        prefs = getSharedPreferences("tasbeeh_prefs", MODE_PRIVATE);
        count = prefs.getInt("count", 0);
        zikrIndex = prefs.getInt("zikrIndex", 0);

        // Bind UI components
        countText = findViewById(R.id.countText);
        zikrText = findViewById(R.id.zikrText);
        incrementButton = findViewById(R.id.incrementButton);
        resetButton = findViewById(R.id.resetButton);
        changeZikrButton = findViewById(R.id.changeZikrButton);

        // Initial UI update
        updateUI();

        // Increment counter
        incrementButton.setOnClickListener(v -> {
            count++;
            updateUI();
        });

        // Reset counter
        resetButton.setOnClickListener(v -> {
            count = 0;
            updateUI();
        });

        // Change zikr phrase
        changeZikrButton.setOnClickListener(v -> {
            zikrIndex = (zikrIndex + 1) % zikrList.length;
            count = 0;
            updateUI();
        });
    }

    private void updateUI() {
        countText.setText(String.valueOf(count));
        zikrText.setText(zikrList[zikrIndex]);
        saveData();
    }

    private void saveData() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("count", count);
        editor.putInt("zikrIndex", zikrIndex);
        editor.apply();
    }
}
